package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.example.model.Product;
import com.example.service.ProductService;

//@RestController
@Controller
//@RequestMapping("/api1")
public class Productctrl {	
	
	 @Autowired
	  private ProductService pds;
	  
	   @GetMapping("/api1")
	    public String viewHomePage(Model model) {
	        model.addAttribute("allproductlist", pds.getAllProduct());
	        return "index2";
	    }
	   
	    @GetMapping("/addnew1")
	    public String addNewProduct(Model model) {
	    	Product product = new Product();
	        model.addAttribute("product", product);
	        return "newproduct"; // html pagename 
	    }
	    
	    @PostMapping("/products")                                      //   ("/save")
	    public String saveProduct(@ModelAttribute("product") Product product) {
	    	pds.save(product);
	        return "redirect:/api";   // -- change to redirect:/
	    }
	    
	    @PutMapping("/products/{id}")                     //@GetMapping      showFormForUpdate
	    public String updateForm(@PathVariable(value = "id") long id, Model model) {
	    	Product product =   pds.getById(id);
	        model.addAttribute("product", product);
	        return "update2";
	    }
	    
	    @DeleteMapping("/products/{id}")                            //@GetMapping   deleteCategory
	    public String deleteThroughId(@PathVariable(value = "id") long id) {
	       pds.deleteViaId(id);
	        return "redirect:/api";    // -- change to redirect:/

}
}
