package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Category;
import com.example.service.CategoryService;

@RestController
//@Controller
//@RequestMapping("/api")
public class Categoryctrl {
	
	  @Autowired(required=true)
	  private CategoryService cts;
	
	  
	   @GetMapping("/api")
	    public String viewHomePage(Model model) {
	        model.addAttribute("allcatlist", cts.getAllCategory());
	        return "index";
	    }
	   
	    @GetMapping("/addnew")                                 //("/addnew")
	    public String addNewCategory(Model model) {
	        Category category = new Category();
	        model.addAttribute("category", category);
	        return "newcategory";
	    }
	    
	    @PostMapping("/categories")                                      //   ("/save")
	    public String saveCategory(@ModelAttribute("category") Category category) {
	    	cts.save(category);
	        return "redirect:/api";   // -- change to redirect:/
	    }
	    
	    @PutMapping("/categories/{id}")                     //@GetMapping      showFormForUpdate
	    public String updateForm(@PathVariable(value = "id") long id, Model model) {
	    	Category category =   cts.getById(id);//employeeServiceImpl.getById(id);
	        model.addAttribute("category", category);
	        return "update";
	    }
	    
	    
	    @DeleteMapping("/categories/{id}")                            //@GetMapping   deleteCategory
	    public String deleteThroughId(@PathVariable(value = "id") long id) {
	        cts.deleteViaId(id);//employeeServiceImpl.deleteViaId(id);
	        return "redirect:/api";    // -- change to redirect:/

	        
}
}
