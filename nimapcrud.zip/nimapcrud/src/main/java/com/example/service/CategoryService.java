package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Category;
import com.example.repository.CategoryRepository;

@Service
public class CategoryService implements CategoryService1{
	
	@Autowired(required=true)
	private CategoryRepository cr;
	
	public CategoryService()
	{
		
	}
	
	

	@Override
	public List<Category> getAllCategory() {
		// TODO Auto-generated method stub
		return cr.findAll();
	}

	@Override
	public void save(Category category) {
		// TODO Auto-generated method stub
		cr.save(category);
		
	}

	@Override
	public Category getById(Long id) {
		 Optional<Category> optional = cr.findById(id);
		 Category category = null;
	        if (optional.isPresent())
	        	category = optional.get();
	        else
	            throw new RuntimeException(
	                "Category not found for id : " + id);
	        return category;
	}

	@Override
	public void deleteViaId(long id) {
		cr.deleteById(id);
		
	}

}
