package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.model.Category;

public interface CategoryService1 {
	
	 List<Category> getAllCategory();
	    void save(Category category);
	    Category getById(Long id);
	    void deleteViaId(long id);

}
