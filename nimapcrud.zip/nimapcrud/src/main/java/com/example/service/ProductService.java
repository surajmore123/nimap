package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Product;
import com.example.repository.ProductRepository;

@Service
public class ProductService implements ProductService1 {
	
	@Autowired
	private ProductRepository pr;
	
	public ProductService()
	{
		
	}

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return pr.findAll();
	}

	@Override
	public void save(Product product) {
		pr.save(product);
		
	}

	@Override
	public Product getById(Long id) {
		 Optional<Product> optional = pr.findById(id); 
		 Product product = null;
	        if (optional.isPresent())
	        	product = optional.get();
	        else
	            throw new RuntimeException(
	                "Product not found for id : " + id);
	        return product;
	}

	@Override
	public void deleteViaId(long id) {
		pr.deleteById(id);
		
	}

}
