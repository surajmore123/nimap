package com.example.service;

import java.util.List;

import com.example.model.Product;



public interface ProductService1 {
	
	 List<Product> getAllProduct();
	    void save(Product product);
	    Product getById(Long id);
	    void deleteViaId(long id);

}
